const swiper = new Swiper('.swiper', {
  // Optional parameters
  // direction: 'vertical',
  speed: 800,
  loop: false,

  // If we need pagination
  pagination: {
    el: '.swiper-pagination',
  },

  // Navigation arrows
  navigation: {
    nextEl: '.swiper__button-next',
    prevEl: '.swiper__button-prev',
  },

  // And if we need scrollbar
  scrollbar: {
    el: '.swiper-scrollbar',
  },

  type: 'progressbar',

  keyboard: {
    enabled : true
  },
  // autoplay: {
  //   delay: 3000,
  //   stopOnLastSlide: false,
  //   disableOnInteraction: true
  // }
});
const modalBtn = document.querySelector(".call-btn");
const modalsBtn = document.querySelector(".call-button");
const offerModalBtn = document.querySelector(".offer__call-btn");
const closeBtn = document.querySelector(".modal__dialog--close");



modalBtn.addEventListener("click", function (){
    document.querySelector(".modal").classList.toggle("modal-active");
});
modalsBtn.addEventListener("click", function (){
    document.querySelector(".modal").classList.toggle("modal-active");
});
offerModalBtn.addEventListener("click", function (){
    document.querySelector(".modal").classList.toggle("modal-active");
});
closeBtn.addEventListener("click", function (){
    document.querySelector(".modal").classList.remove("modal-active");
});